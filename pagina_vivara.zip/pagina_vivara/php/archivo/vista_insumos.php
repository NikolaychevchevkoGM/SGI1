<?php
include_once('../config.php');
include_once('select.php');
// $query = ("SELECT * FROM insumos");
$records = [];
$records = fetchAll($conex);
?>

<!DOCTYPE html>
<html lang="en">
  <head>
      <link rel="stylesheet" href="../vista_insumos.css"></link>
      <title>Insumos</title>
  </head>
    <body>
    <b> <center><h1>INSUMOS</h1></center> </b> <br> <br>
      <center> <table border="6">
                <thead>
                  <tr align="center">
                    <th> ID </th>
                    <th>Nombre insumo</th>
                    <th>Descripcion</th>
                    <th>Fecha</th>
                    <th>Cantidad de lotes</th>
                    <th>ID proveedor</th>
                  </tr>
                </thead>
                  <tbody data-link="row" class="rowlink">
                  <?php
                  if(count($records)){
                    foreach($records as $row){
                    ?>
                      <tr align="center">
                        <td><?php echo $row->id_insumo; ?></td>
                        <td><?php echo $row->nomb_insumo; ?></td>
                        <td><?php echo $row->descripcion; ?></td>
                        <td><?php echo $row->fecha_ingreso; ?></td>
                        <td><?php echo $row->unidades; ?></td>
                        <td><?php echo $row->proveedor_id; ?></td>
                        <td> <a href="borrar_insumos.php?id=<?php echo $row->id_insumo;?>">Borrar</a> </td>
                      </tr>
                    <?php }
                   } else { ?>
                  <tr>
                    <td colspan="6">No se pudo encontrar registros.</td>
                  </tr>
                  <?php } ?>
                  
                </tbody>
              </table>
      </center>
    </body>
</html>